const handleCreateGroupItem = () => {
    const contentDOM = document.getElementById("content");

    const infoDOM = document.createElement("div");
    infoDOM.classList.add("info");
    infoDOM.innerHTML = `
        <div class="info-header">
            <h1 
                class="info-header--des"
                ondblclick="handleChangeGroupName(event)"
            >
                Group Item_20194776
            </h1>
            <div class="info-header-line"></div>
            <div class="info-header-btn">
                <i 
                    class="fa-regular fa-trash-can trash-btn"
                    onclick="handleDeleteGroup(event)"
                ></i>
                <button 
                    class="btn add-item"
                    onclick="handleAddItem(event)"
                >
                    Add info item
                </button>
                <button 
                    class="btn add-group"
                    onclick="handleCreateGroupItem()"
                >
                    Add group item
                </button>
            </div>
        </div>
        <div class="info-content">
        </div>    
    `;

    contentDOM.appendChild(infoDOM);
};

const handleChangeGroupName = (event) => {
    const infoHeaderDOM = event.target;
    const parentDOM = infoHeaderDOM.parentNode;

    const infoHeaderInput = document.createElement("input");
    infoHeaderInput.classList.add("info-header-input");
    infoHeaderInput.type = "text";
    infoHeaderInput.placeholder = "Nhập tên group...";
    infoHeaderInput.onkeypress = handleChangeInfoHeader;

    parentDOM.removeChild(infoHeaderDOM);
    parentDOM.insertBefore(infoHeaderInput, parentDOM.firstChild);
};

const handleChangeInfoHeader = (event) => {
    const infoHeaderInput = event.target;
    const parentDOM = infoHeaderInput.parentNode;
    if (event.key === "Enter") {
        const text = `${event.target.value}_20194776`;
        const infoHeaderDOM = document.createElement("h1");
        infoHeaderDOM.classList.add("info-header--des");
        infoHeaderDOM.ondblclick = handleChangeGroupName;
        infoHeaderDOM.innerHTML = text;

        parentDOM.removeChild(infoHeaderInput);
        parentDOM.insertBefore(infoHeaderDOM, parentDOM.firstChild);
    }
};

const handleDeleteGroup = (event) => {
    const infoDOM = event.target.parentNode.parentNode.parentNode;
    const contentDOM = infoDOM.parentNode;
    const text = `HỌ TÊN: Lê Đình Huy \nMÃ SỐ SINH VIÊN: 20194776\nBạn có muốn xóa nhóm thông tin không?`;

    if (confirm(text) === true) {
        contentDOM.removeChild(infoDOM);
    }
};

const handleAddItem = (event) => {
    const infoDOM = event.target.parentNode.parentNode.parentNode;
    const infoContentDOM = infoDOM.querySelector(".info-content");
    const text = `
        <input
            class="info-content--des__input col-span-5"
            placeholder="Nhập tiêu đề..."
        />
        <input
            class="info-content--des__input col-span-5"
            placeholder="Nhập giá trị..."
        />
        <i
            class="fa-solid fa-circle-check info-content-btn col-span-1"
            onclick="handleSubmitItem(event)"
        ></i>
        <i
            class="fa-regular fa-trash-can info-content-btn col-span-1"
            onclick="handleDeleteItem(event)"
        ></i>
    `;

    const infoContentDes = document.createElement("div");
    infoContentDes.classList.add("info-content--des", "grid", "grid-cols-12");
    infoContentDes.innerHTML = text;
    infoContentDOM.appendChild(infoContentDes);
};

const handleSubmitItem = (event) => {
    const parentInputDOM = event.target.parentNode;
    const inputItemTitleDOM = parentInputDOM.querySelectorAll(
        ".info-content--des__input"
    )[0];
    const inputItemValueDOM = parentInputDOM.querySelectorAll(
        ".info-content--des__input"
    )[1];

    const infoContentDOM = parentInputDOM.parentNode;
    const text = `
        <h1 
            class="info-content--des__title col-span-5"
            ondblclick="handleChangeItem(event)"
        >
            ${inputItemTitleDOM.value}:
        </h1>
        <p 
            class="info-content--des__value col-span-5"
            ondblclick="handleChangeItem(event)"
        >
            ${inputItemValueDOM.value}
        </p>
        <i
            class="fa-regular fa-trash-can info-content-btn col-span-1"
            onclick="handleDeleteItem(event)"
        ></i>
    `;
    const infoContentDes = document.createElement("div");
    infoContentDes.classList.add("info-content--des", "grid", "grid-cols-11");
    infoContentDes.innerHTML = text;

    infoContentDOM.removeChild(parentInputDOM);
    infoContentDOM.appendChild(infoContentDes);
};

const handleDeleteItem = (event) => {
    const parentContentDes = event.target.parentNode;
    const infoContentDOM = parentContentDes.parentNode;
    const text = `HỌ TÊN: Lê Đình Huy \nMÃ SỐ SINH VIÊN: 20194776\nBạn có muốn xóa trường thông tin không?`;

    if (confirm(text) === true) {
        infoContentDOM.removeChild(parentContentDes);
    }
};

const handleChangeItem = (event) => {
    const childDOM = event.target;
    const parentDOM = childDOM.parentNode;
    const flag = childDOM === parentDOM.childNodes[1] ? true : false;

    const childInput = document.createElement("input");
    childInput.classList.add("info-content--des__input", "col-span-5");
    childInput.type = "text";
    childInput.placeholder = flag ? "Nhập tiêu đề..." : "Nhập giá trị...";
    childInput.onkeypress = handleChangeInfoItem;

    parentDOM.removeChild(childDOM);
    flag
        ? parentDOM.insertBefore(childInput, parentDOM.firstChild)
        : parentDOM.insertBefore(childInput, parentDOM.childNodes[3]);
};

const handleChangeInfoItem = (event) => {
    const childInput = event.target;
    const parentDOM = childInput.parentNode;
    const flag = childInput === parentDOM.childNodes[0] ? true : false;

    console.log(parentDOM.childNodes);

    if (event.key === "Enter") {
        const text = flag ? `${event.target.value}:` : `${event.target.value}`;
        const childDOM = flag
            ? document.createElement("h1")
            : document.createElement("p");
        flag
            ? childDOM.classList.add("info-content--des__title", "col-span-5")
            : childDOM.classList.add("info-content--des__value", "col-span-5");
        childDOM.ondblclick = handleChangeItem;
        childDOM.innerHTML = text;

        parentDOM.removeChild(childInput);
        flag
            ? parentDOM.insertBefore(childDOM, parentDOM.firstChild)
            : parentDOM.insertBefore(childDOM, parentDOM.childNodes[3]);
    }
};
